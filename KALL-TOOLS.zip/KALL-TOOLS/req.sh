apt install nodejs npm -y
npm install -g bash-obfuscate
termux-setup-storage -y;
