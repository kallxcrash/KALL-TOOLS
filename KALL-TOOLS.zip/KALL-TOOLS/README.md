PASTE IN TERMUX

apt install git python -y && git clone https://github.com/kallxcrash/KALL-TOOLS.git && cd KALL-TOOLS && bash req.sh && python3 kt.py
